module.exports = {
  norpc: true,
  skipFiles: ['Array256Lib.sol','BasicMathLib.sol','CrowdsaleToken.sol','CrowdsaleLib.sol','LinkedListLib.sol','TokenLib.sol'],
};
